package com.cg.service;

import org.springframework.stereotype.Service;

/**
 * 
 * @author sgawhad service class for login
 */
@Service
public class LoginServiceImpl implements LoginService {

	/**
	 * 
	 * @param userid
	 * @param password
	 * @return if userid && password matches the given value return true else return
	 *         false
	 */
	public boolean validateUser(String userid, String password) {
		return userid.equals("admin@gmail.com") && password.equals("123456");
	}

}