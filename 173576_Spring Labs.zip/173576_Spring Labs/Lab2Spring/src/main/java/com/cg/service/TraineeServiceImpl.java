package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;

@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeRepo repo;

	@Override
	public String addTrainee(Trainee trainee) {
		repo.save(trainee);
		return "Trainee saved successfullf";
	}

	@Override
	public Trainee retriveTrainee(int id) {
		return repo.findById(id).get();

	}

	@Override
	public String modifyTrainee(Trainee trainee) {
		repo.save(trainee);
		return "Trainee details modified";
	}

	@Override
	public String deleteTrainee(int id) {
		repo.deleteById(id);
		return "Trainee deleted successfully";
	}

	@Override
	public List<Trainee> retriveAll() {
		return (List<Trainee>) repo.findAll();
	}

}
