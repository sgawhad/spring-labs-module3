package com.cg.service;

public interface LoginService {

	boolean validateUser(String userid, String password);
}
