package com.cg.service;

import java.util.List;

import com.cg.entity.Trainee;

public interface TraineeService {

	String addTrainee(Trainee trainee);

	Trainee retriveTrainee(int id);

	String modifyTrainee(Trainee trainee);

	String deleteTrainee(int id);

	List<Trainee> retriveAll();
}
