package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService serviceTrainee;

	Trainee trainee;

	@RequestMapping(value = "/showAddtrainee")
	public String showAddTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());

		return "addTrainee";

	}

	@RequestMapping(value = "/trainee")
	public String trainee() {
		return "success";
	}

	@RequestMapping(value = "/addtrainee")
	public String addTrainee(@ModelAttribute("trainee") Trainee trainee, Model model) {
		serviceTrainee.addTrainee(trainee);
		return "addSuccess";
	}

	@RequestMapping(value = "/showDeleteTrainee")
	public String showDeleteTrainee() {
		return "deleteTrainee";
	}

	@RequestMapping("/search")
	public String searchTrainee(Model model, int traineeId) {

		trainee = serviceTrainee.retriveTrainee(traineeId);
		model.addAttribute("deleteTrainee", trainee);
		return "deleteTrainee";
	}

	@RequestMapping(value = "/delete")
	public String deleteTrainee() {
		System.out.println(trainee);
		serviceTrainee.deleteTrainee(trainee.getTraineeId());
		return "deleteSuccess";
	}

	@RequestMapping(value = "/showRetriveTrainee")
	public String showRetriveTrainee(Model model) {
		return "retriveTrainee";
	}

	@RequestMapping(value = "/retriveTrainee")
	public String retriveTrainee(Model model, int traineeId) {
		trainee = serviceTrainee.retriveTrainee(traineeId);
		System.out.println(trainee);
		model.addAttribute("retriveTrainee", trainee);
		return "retriveTrainee";

	}

	@RequestMapping(value = "showRetriveAll")
	public String retriveAll(Model model) {

		Iterable<Trainee> allTrainee = serviceTrainee.retriveAll();
		model.addAttribute("allTrainee", allTrainee);
		return "retriveAll";
	}

	@RequestMapping(value = "showModifyTrainee")
	public String showModifyTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "modifyTrainee";
	}

	@RequestMapping(value = "modify")
	public String modify(Model model, int traineeId) {
	
		trainee = serviceTrainee.retriveTrainee(traineeId);

		model.addAttribute("trainee", trainee);
		
		model.addAttribute("modifyTrainee", trainee);
		return "modifyTrainee";
	}

	@RequestMapping(value = "modifyTrainee")
	public String modifyTrainee(@ModelAttribute("trainee") Trainee modifyTrainee, Model model) {

		serviceTrainee.addTrainee(modifyTrainee);
		model.addAttribute("modifyTrainee", modifyTrainee);
		return "modifySuccess";

	}
}
