import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ioc.Employee;
import com.cg.ioc.Sbu;

public class TestEmployee {

	@Test
	public void testEmployeeObj () {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		
		Sbu sbu = (Sbu) ctx.getBean("sbu");
		
		Employee e1 = new Employee(1002, "Mayur", 5000);
		sbu.addEmployee(e1);
		
		Employee e2 = new Employee(1003, "Varsha", 5000);
		sbu.addEmployee(e2);
		System.out.println(sbu);
		
		
		
	}
}
