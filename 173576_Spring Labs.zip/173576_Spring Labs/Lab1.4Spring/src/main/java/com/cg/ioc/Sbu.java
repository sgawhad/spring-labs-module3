package com.cg.ioc;

import java.util.ArrayList;
import java.util.List;

public class Sbu {

	private int sbuId;
	private String sbuName;
	private String sbuHead;

	private List<Employee> empList = new ArrayList<Employee>();

	public Sbu() {
	}

	public Sbu(int sbuId, String sbuName, String sbuHead, List<Employee> empList) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.empList = empList;
	}

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public void addEmployee(Employee emp) {
		empList.add(emp);
	}

	public Employee findEmp(int id) {
		for (Employee employee : empList) {
			if(employee.getEmployeeId()==id) {
				return employee;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "SbuId = " + sbuId + "\nSbu Name = " + sbuName + "\nSbu Head = " + sbuHead + "\nList=" + empList;
	}

}
